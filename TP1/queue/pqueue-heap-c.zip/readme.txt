Source code information.

These files are presented as part of the A* Algorihm mini
tutorial found on the web page at :

http://www.geocities.com/SiliconValley/Lakes/4929/astar.html

The legal message there applies here.

File descriptions :

Name				Contents
************************************************************

readme.txt			This information

pqueue.cpp			Code for manipulating a priority queue
pqueue.h

wlist.cpp			Code for a simple linked list
list.h			

jhjtypes.h			Data types used are defined here
