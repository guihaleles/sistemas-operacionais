// Data types used in JHeyes-Jones sample code

typedef long int int32;
typedef unsigned long int uint32;
typedef short int16;			  
typedef unsigned short uint16;
typedef signed char int8;
typedef unsigned char uint8;